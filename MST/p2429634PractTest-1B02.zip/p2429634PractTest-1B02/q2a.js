/*
    Question 2a 
    Name: Zhang Junkai
    Admin No: p2429634
    Class: DIT1B02
*/

function createMultiplier(x) { 
    const func = (y) => x*y;
    return func;
}

// Test Case 1
// const double = createMultiplier(2); 
// console.log(double(5)); 

// Test Case 2
// const triple = createMultiplier(3); 
// console.log(triple(12)); 
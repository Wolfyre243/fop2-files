/*
    Question 3
    Name: Zhang Junkai
    Admin No: p2429634
    Class: DIT1B02
*/


function apply(value, func) {
    return func(value);
}

function areaOfSquare (x) {
    return x**2
}

function perimeterOfSquare(x) {
    return x*4
}


// Test case
// let x = 3;
// console.log("Area of square 3 is " + apply(x, areaOfSquare));			     
// console.log("Perimeter of square 3 is " + apply(x, perimeterOfSquare));				     

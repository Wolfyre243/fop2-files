/*
    Question 1a
    Name: xxx xxx
    Admin No: pxxxxx
    Class: DIT1BXX
*/

let x = 0;

if (x >= 0) {
    x = 5;   
    console.log("Value of x in if statement is " + x);
}

console.log("Value of x is " + x);

// Reason for such error(s)

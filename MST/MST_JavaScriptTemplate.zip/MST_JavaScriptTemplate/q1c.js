/*
    Question 1c
    Name: xxx xxx
    Admin No: pxxxxx
    Class: DIT1BXX
*/

let numArray = [1, 6, 9, 3, 10, 16];
// Do not remove the evenArray array.
evenArray = [2, 4, 8];

function getEven(ary) {
    for (let x = 0; x < ary.length; x++) {
        if (ary[x] % 2 == 0) {
            evenArray.push(ary[x]);
        }
    }
    return evenArray;
}

console.log(getEven(numArray));

// Reason for such error(s)

/*
    Question 3
    Name: xxx xxx
    Admin No: pxxxxx
    Class: DIT1BXX
*/


function apply(value, func) {
    /* TODO: Add code here */
}

function areaOfSquare (x) {
    /* TODO: Add code here */   
}

function perimeterOfSquare(x) {
    /* TODO: Add code here */
}


// Test case
// let x = 3;
// console.log("Area of square 3 is " + apply(x, areaOfSquare));			     
// console.log("Perimeter of square 3 is " + apply(x, perimeterOfSquare));				     

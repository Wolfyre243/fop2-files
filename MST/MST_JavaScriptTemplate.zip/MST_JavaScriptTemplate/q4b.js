/*
    Question 4b
    Name: xxx xxx
    Admin No: pxxxxx
    Class: DIT1BXX
*/

const productObjArr = [
    {name: "Laptop", price: 1500, quantity: 5, category: "Electronics"},
    {name: "Book", price: 20, quantity: 0, category: "Stationery"},
    {name: "Smartphone", price: 800, quantity: 3, category: "Electronics"},
    {name: "Pen", price: 2, quantity: 10, category: "Stationery"}
];

function getAvailableProducts(products) {

    const availableProducts = products
        .filter(/* (i) TODO: Add code here */) 
        .sort(/* (ii) TODO: Add code here */) 
        .map(/* (iii) TODO: Add code here */); 

    return /* (iv) TODO: Add code here */; 
}

console.clear();
console.log("All products:");
console.table(productObjArr);

console.log("Available products:");
console.table(getAvailableProducts(productObjArr));

/*
    Question 2a 
    Name: xxx xxx
    Admin No: pxxxxx
    Class: DIT1BXX
*/

function createMultiplier(x) { 
    
    /* (a) TODO : Add code here */
    
}

// Test Case 1
// const double = createMultiplier(2); 
// console.log(double(5)); 

// Test Case 2
// const triple = createMultiplier(3); 
// console.log(triple(12)); 
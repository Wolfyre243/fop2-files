/*
    Question 4a
    Name: xxx xxx
    Admin No: pxxxxx
    Class: DIT1BXX
*/

const words = ["apple", "pear", "apple", "orange", "orange", "apple", "pear", "apple"];

// initialize empty object for counting words
let wordCount = /* (i) TODO: Add code here */;

// for tracking the number of unique word found
let uniqueWordCount = 0;

// Loop through the array and count occurrences
for (let word of /* (ii) TODO: Add code here */) {

    // word exist in wordCount  
    if (/*(iii) TODO: Add code here */) {

    // increase the count
    /*(iv) TODO: Add code here */;

    } else {

    // first occurrence of word
    /* (v) TODO: Add code here */;

    // Increase the unique word count 
    // when a new word is found

    /*(vi) TODO: Add code here */;
    }
}

console.clear();
console.log("Number of unique words:", uniqueWordCount);
console.log("Word occurrences:")
console.table(wordCount);




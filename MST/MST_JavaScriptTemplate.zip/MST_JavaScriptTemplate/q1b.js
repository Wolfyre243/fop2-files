/*
    Question 1b
    Name: xxx xxx
    Admin No: pxxxxx
    Class: DIT1BXX
*/

let numArray = [1,6,9,3,10,6];
let indexes;

for (let x = 0; x < numArray.length; x++) {
    let indexes = [];   
    if (numArray[x] % 2 == 0){
         indexes.push(x);
    }
}

console.log(indexes); 

// Reason for such error(s)



/*
    Question 5
    Name: xxx xxx
    Admin No: pxxxxx
    Class: DIT1BXX
*/

// Online Sales Data
const salesData = require('./onlinesalesdata');

// Part 5a 
function printProductInfo(data) {

    /* TODO: Add code here */

}

// Test case 
// printProductInfo(salesData);

// Part 5b 
function displayHighestLowestPrice (data) {
 
    /* TODO: Add code here */

}

// Test case 
// displayHighestLowestPrice(salesData);

// Part 5c 
function totalPaymentByPayMethod (data, paymentMethod) {

    /* TODO: Add code here */

}

// Test case 1
// totalPaymentByPayMethod(salesData, "PayPal");

// Test case 2
// totalPaymentByPayMethod(salesData, "Debit Card");

// Part 5d
function sumByCategory(data){

    /* TODO: Add code here */

}

// Test case
// let result = sumByCategory(salesData);
// console.log(result);

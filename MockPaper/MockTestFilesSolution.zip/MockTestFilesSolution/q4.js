/* 
	Question 4
	Name: Tan Chan Lim
	Admin No: p1234567
	Class: DIT1B01
	
*/

let flower = ["Orchid", "Rose", "Sunflower", "Lily", "Peony"];

/*
    TODO: Fill up the code part a
*/
console.log(flower);
/*
    TODO: Fill up the code part b
*/

flower.pop();
/*
    TODO: Fill up the code part c
*/


flower.sort((a, b) => a.toLowerCase() < b.toLowerCase() ? 1 : -1);
console.log(flower);


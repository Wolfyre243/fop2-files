/* 
	Question 1a
	Name: Tan Chan Lim
	Admin No: p1234567
	Class: DIT1B01
	
*/

let x = 2 * 7 ;

function multiplyTen (z) {
  let x  = z * 10 ;
  return x;
}

xTen = multiplyTen (5);

console.log("5 multiply by ten is " + xTen);

console.log("The value of variable x is " + x);

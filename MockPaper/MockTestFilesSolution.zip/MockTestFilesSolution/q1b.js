/* 
	Question 1b
	Name: Tan Chan Lim
	Admin No: p1234567
	Class: DIT1B01
	
*/

function typeOfPet() {
    var pet_type = "dog";
    console.log("My pet is a " + myPet());

    function myPet() {
        var other_pet = "cat";
        return other_pet ;
    }

    myPet();
}

typeOfPet();

/* 
	Question 1a
	Name: Zhang Junkai
	Admin No: p2429634
	Class: DIT1B02
	
*/

x = 2 * 7;

function multiplyTen (z) {
  const x  = z * 10 ;
  return x;
}

xTen = multiplyTen (5);

console.log("5 multiply by ten is " + xTen);

console.log("The value of variable x is " + x);

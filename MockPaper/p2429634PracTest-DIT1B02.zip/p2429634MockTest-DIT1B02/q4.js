/* 
	Question 4
	Name: Zhang Junkai
	Admin No: p2429634
	Class: DIT1B02
	
*/

let flower = ["Orchid", "Rose", "Sunflower", "Lily", "Peony"];

/*
    TODO: Fill up the code part a
*/
console.log(flower);

/*
    TODO: Fill up the code part b
*/
flower.pop();
console.log(flower);

/*
    TODO: Fill up the code part c
*/
flower.sort().reverse();
console.log(flower);


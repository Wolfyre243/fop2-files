// Fill up the code for the question
const readline = require("readline-sync");
const fetch = require('node-fetch');

